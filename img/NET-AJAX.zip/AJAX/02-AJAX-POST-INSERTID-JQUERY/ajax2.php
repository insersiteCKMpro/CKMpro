<?php 
require_once('init.php');

$tab = array();

//-------- REQUETE D'INSERTION 
// Exo : réaliser le script permettant d'insérer un employé (seulement la champ 'prenom') dans la table 'employes' de la BDD entreprise


if(!empty($_POST['prenom']))
{
    // requête test : 
    // $result = $bdd->exec("INSERT INTO employes (prenom) VALUES ('Grégory')");
                                                                // tata78
    $result = $bdd->exec("INSERT INTO employes (prenom) VALUES ('$_POST[prenom]')"); 
    // On définit un indice $_POST[prenom], cela nous permettra d'envoyer un paramètre à la requete SQL via une requête AJAX 

    $tab['msg'] = "<p class='col-md-5 mx-auto text-center alert alert-success'>L'employé <strong>$_POST[prenom]</strong> a bien été enregistré !!</p>"; 
}
else
{
    $tab['msg'] = "<p class='col-md-5 mx-auto text-center alert alert-danger'>Merci de remplir le formulaire !!</p>"; 
}

echo json_encode($tab); // nous sommes obligé d'encoder la réponse de la requete RETOUR AJAX afin de véhiculer les données en http