<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script
    src="https://code.jquery.com/jquery-3.4.1.min.js"
    integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
    crossorigin="anonymous"></script>
    <script src="ajax2.js"></script>
    <title>02 - AJAX - POST - INSERTID - JQUERY</title>
</head>
<body>
    <div class="container">

        <h1 class="display-4 text-center">02 - AJAX - POST - INSERTID - JQUERY</h1><hr>

        <div id="resultat"></div>

        <form method="post" class="col-md-4 mx-auto text-center" id="form1">
            <div class="form-group">
                <label for="prenom">Prénom</label>
                <input type="text" class="form-control" id="prenom" name="prenom">
            </div>
            <button type="submit" id="submit" class="col-md-12 btn btn-dark">Enregistrer</button>
        </form>
    </div>
</body>
</html>