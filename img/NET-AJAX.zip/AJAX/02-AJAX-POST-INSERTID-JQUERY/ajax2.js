$(document).ready(function(){

    // On selectionne le bouton 'submit' auquel on associe l'évènement 'click'
    $('#submit').click(function(event){
        event.preventDefault(); // On annule le comportement du bouton 'submit' qui a pour rôle de recharger le code
        //alert('Tout est OK !!');

        ajaxInsertId(); // pour chaque sur le bouton, on execute la fonction ajaxInsertId() déclarée ci dessous
    });

    function ajaxInsertId()
    {
        var prenom = $('#prenom').val(); // on stock dans une variable le prenom saisie dans le formulaire
        console.log(prenom);

        var parameters = "prenom="+prenom; // on définit un paramètre à transmettre avec la requete ALLER AJAX 
        // "prenom=" : correspond à l'indice $_POST['prenom'] déclarée dans le fichier ajax2.php
        console.log(parameters);

        // $.post : méthode jquery permettant d'executer des requêtes AJAX avec la méthode $_POST
        /*
            arguments : 
            1. fichier de destination
            2. les paramètres à fournir à la requete AJAX
            3. en cas succés de requête AJAX, la réponse de la requête RETOUR est stocké dans 'data', dans notre cas le message de validation d'insertion
            4. le type de donnée véhiculé : JSON
        */
        $.post("ajax2.php", parameters, function(data){
            console.log(data);

            $('#resultat').html(data.msg); // on selectionne la div ID 'resultat' pour lui envoyer le message de validation contenu dans 'data', donc la réponse de la requête RETOUR AJAX
            // data.msg : 'msg' correspond à l'indice $tab['msg'] déclarée dans la fichier ajax2.php

        }, 'json');

        $('#form1')[0].reset(); // on reboot le formulaire afin de vider le champs aprés validation du formulaire

    }
    
});