<?php 
require_once('init.php');
$tab = array();

//-------- REQUETE SELECTION SERVICE
$result = $bdd->query("SELECT * FROM employes WHERE service = '$_POST[service]'");
// $result = $bdd->query("SELECT * FROM employes WHERE service = 'commercial'");

//-------- AFFICHAGE DES EMPLOYES PAR SERVICE 
$tab['tableEmploye'] = '<table class="table table-bordered text-center"><tr>';
for($i = 0; $i < $result->columnCount(); $i++)
{
    $colonne = $result->getColumnMeta($i);
    $tab['tableEmploye'] .= "<th>$colonne[name]</th>";
}
$tab['tableEmploye'] .= '</tr>';
while($employe = $result->fetch(PDO::FETCH_ASSOC))
{
    $tab['tableEmploye'] .= '<tr>';
    foreach($employe as $value)
    {
        $tab['tableEmploye'] .= "<td>$value</td>";
    }
    $tab['tableEmploye'] .= '</tr>';
}

echo json_encode($tab);