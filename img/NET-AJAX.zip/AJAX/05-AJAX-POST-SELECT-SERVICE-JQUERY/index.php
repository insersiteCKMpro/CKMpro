<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script
    src="https://code.jquery.com/jquery-3.4.1.min.js"
    integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
    crossorigin="anonymous"></script>
    <script src="ajax5.js"></script>
    <title>05 - AJAX - POST - SELECT - SERVICE - JQUERY</title>
</head>
<body>
    <div class="container">

        <h1 class="display-4 text-center">05 - AJAX - POST - SELECT - SERVICE - JQUERY</h1><hr>

        <!-- 
        Exo : réaliser un filtre AJAX permettant de filtrer les employés par service 
        - déclarer un selecteur avec les services distinct sur la page index 
        - Afficher l'ensemble des employés sous forme de tableau ARRAY sur la page index.php 
        - Associer l'évènement 'change()' au selecteur (en remplacement de l'évènement click())
        -->
        <form method="post" action="" class="col-md-4 mx-auto text-center">
            <?php 
            require_once('init.php');
            $result = $bdd->query('SELECT DISTINCT service FROM employes');
            echo '<select class="form-control mb-2" id="service">';
            while($employes = $result->fetch(PDO::FETCH_ASSOC))
            {
                echo "<option value='$employes[service]'>$employes[service]</option>";
            }
            echo '</select>';
            ?>
        </form>

        <div id="resultat">
        <?php 
        $result = $bdd->query('SELECT * FROM employes');
        echo '<table class="table table-bordered text-center"><tr>';
        for($i = 0; $i < $result->columnCount(); $i++)
        {
            $colonne = $result->getColumnMeta($i);
            echo "<th>$colonne[name]</th>";
        }
        echo '</tr>';
        while($employes = $result->fetch(PDO::FETCH_ASSOC))
        {
            echo '<tr>';
            foreach($employes as $value)
            {
                echo "<td>$value</td>";
            }
            echo '</tr>';
        }
        echo '</table>';
        ?>
        </div>

    </div>
</body>
</html>