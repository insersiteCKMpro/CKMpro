$(document).ready(function(){

    $('#service').change(function(){

        // alert('change OK !!');
        ajaxSelectService();
    });

    function ajaxSelectService()
    {
        var service = $('#service').val();
        console.log(service); 

        var parameters = "service="+service;
        console.log(parameters); 

        $.post("ajax5.php", parameters, function(data){
            console.log(data);
            $('#resultat').html(data.tableEmploye);
        }, 'json');
    }

});