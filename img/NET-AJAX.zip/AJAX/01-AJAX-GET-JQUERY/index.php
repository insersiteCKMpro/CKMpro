<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>01 - AJAX - GET</title>
</head>
<body>
    <div class="container">

        <h1 class="display-4 text-center">01 - AJAX - GET</h1><hr>

        <div id="demo" class="col-md-4 mx-auto p-3 mb-3 border border-dark"></div>

        <button type="button" id="action" class="col-md-2 offset-md-5 btn btn-dark">Charger fichier TXT</button>

    </div>

    <script
    src="https://code.jquery.com/jquery-3.4.1.min.js"
    integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
    crossorigin="anonymous"></script>

    <script>
        // On selectionne le DOM, la fonction anonyme sera executée seulement dans le cas où le DOM sera entièrement chargé (ready)
        $(document).ready(function(){
            // On selectionne le bouton id 'action' auquel on associe l'évènement 'click', à chaque fois que l'on clqie sur le bouton, la fonction anonyme s'execute 
            $('#action').click(function(){
                // alert('evènement click OK !!');
                /*
                ajax() : méthode jquery permettant d'executer des requetes AJAX http
                Il y a toujours 2 requêtes : une requête aller et retour
                url : URL de destiantion de la requete AJAX 
                dataType : type de donnée attendue
                success : si la requete est bien passée, la fonction anonyme s'execute et le résultat, c'est à dire le contenu du fichier text se trouve dans la variable de réception 'data'
                */
                $.ajax({
                    url : "ajaxInfo.txt",
                    dataType : "text",
                    success : function(data) {
                        $('#demo').html(data); // on selectionne la div id 'demo' afin de lui transmettre le contenu du fichier text via la méthode 'html()' de jquery
                    }
                });
            });
        });
    </script>
</body>
</html>