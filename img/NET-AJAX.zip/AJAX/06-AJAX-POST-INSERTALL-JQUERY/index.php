<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script
    src="https://code.jquery.com/jquery-3.4.1.min.js"
    integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
    crossorigin="anonymous"></script>
    <script src="ajax6.js"></script>
    <title>06 - AJAX - POST - INSERTALL - JQUERY</title>
</head>
<body>
    <div class="container">

        <h1 class="display-4 text-center">06 - AJAX - POST - INSERTALL - JQUERY</h1>

        <!-- 
        Exo : réaliser un script AJAX permettant d'insérer un employé dans la BDD avec tout les champs (prenom, sexe,service, date_embauche, salaire) 
        - Créer un formulaire HTML correspondant à la table 'employes' (sauf id_employes)
        - Afficher l'ensemble des employés sous forme de tableau ARRAY sur la page index.php 
        -->

        <div id="resultat">
            <?php 
            require_once('init.php');
            $result = $bdd->query('SELECT * FROM employes');
            echo '<table class="table table-bordered text-center"><tr>';
            for($i = 0; $i < $result->columnCount(); $i++)
            {
                $colonne = $result->getColumnMeta($i);
                echo "<th>$colonne[name]</th>";
            }
            echo '</tr>';
            while($employes = $result->fetch(PDO::FETCH_ASSOC))
            {
                echo '<tr>';
                foreach($employes as $value)
                {
                    echo "<td>$value</td>";
                }
                echo '</tr>';
            }
            echo '</table>';
            ?>
        </div>

        <form method="post" id="form" class="col-md-6 mx-auto mb-3">
            <div class="form-row mb-2">
                <div class="col">
                <input type="text" class="form-control" id="prenom" name="prenom" placeholder="Prénom">
                </div>
                <div class="col">
                <input type="text" class="form-control" id="nom" name="nom" placeholder="Nom">
                </div>
            </div>
            <div class="form-row mb-2">
                <div class="col">
                <select id="sexe" name="sexe" class="form-control">
                    <option value="m">Homme</option>
                    <option value="f">Femme</option>
                </select>
                </div>
                <div class="col">
                <input type="text" class="form-control" id="service" name="service" placeholder="Service">
                </div>
            </div>
            <div class="form-row mb-2">
                <div class="col">
                <input type="date" class="form-control" id="date_embauche" name="date_embauche">
                </div>
                <div class="col">
                <input type="text" class="form-control" id="salaire" name="salaire" placeholder="Salaire">
                </div>
            </div>
            <input type="submit" id="submit" value="Enregistrer" class="col-md-12 btn btn-dark">
        </form>
    </div>
</body>
</html>