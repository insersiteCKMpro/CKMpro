<?php 
require_once('init.php');

$tab = array();

//------- REQUETE INSERTION
$result = $bdd->prepare("INSERT INTO employes (prenom,nom,sexe,service,date_embauche,salaire) VALUES (:prenom,:nom,:sexe,:service,:date_embauche,:salaire)");
$result->bindValue(':prenom', $_POST['prenom'], PDO::PARAM_STR);
$result->bindValue(':nom', $_POST['nom'], PDO::PARAM_STR);
$result->bindValue(':sexe', $_POST['sexe'], PDO::PARAM_STR);
$result->bindValue(':service', $_POST['service'], PDO::PARAM_STR);
$result->bindValue(':date_embauche', $_POST['date_embauche'], PDO::PARAM_STR);
$result->bindValue(':salaire', $_POST['salaire'], PDO::PARAM_INT);
$result->execute();

//------ REQUETE SELECTION + AFFICHAGE EMPLOYES
$result = $bdd->query('SELECT * FROM employes');
$tab['tableEmployes'] = '<table class="table table-bordered text-center"><tr>';
for($i = 0; $i < $result->columnCount(); $i++)
{
    $colonne = $result->getColumnMeta($i);
    $tab['tableEmployes'] .= "<th>$colonne[name]</th>";
}
$tab['tableEmployes'] .= '</tr>';
while($employes = $result->fetch(PDO::FETCH_ASSOC))
{
    $tab['tableEmployes'] .= '<tr>';
    foreach($employes as $value)
    {
        $tab['tableEmployes'] .= "<td>$value</td>";
    }
    $tab['tableEmployes'] .= '</tr>';
}
$tab['tableEmployes'] .= '</table>';

echo json_encode($tab);
