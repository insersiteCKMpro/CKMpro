<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script
    src="https://code.jquery.com/jquery-3.4.1.min.js"
    integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
    crossorigin="anonymous"></script>
    <script src="ajax3.js"></script>
    <title>03 - AJAX - POST - DELETEID - JQUERY</title>
</head>
<body>
    <div class="container">

        <h1 class="display-4 text-center">03 - AJAX - POST - DELETEID - JQUERY</h1><hr>

        <div id="resultat"></div>

        <form method="post" action="" class="col-md-4 mx-auto text-center">
            <div id="selectEmployes">
                <?php 
                require_once('init.php');
                $result = $bdd->query('SELECT * FROM employes');
                echo '<select class="form-control mb-2" id="prenom">';
                while($employes = $result->fetch(PDO::FETCH_ASSOC))
                {
                    echo "<option value='$employes[id_employes]'>$employes[id_employes] - $employes[prenom]</option>";
                }
                echo '</select>';
                ?>
            </div>
            <input type="submit" id="submit" class="col-md-12 btn btn-dark" value="Supprimer">
        </form>

    </div>
</body>
</html>