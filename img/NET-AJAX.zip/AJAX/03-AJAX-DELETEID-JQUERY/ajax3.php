<?php 
require_once('init.php');

$tab = array();

//--------- REQUETE SQL DELETE 
// Exo : réaliser la requete de suppression (DELETE) permettant de supprimer un employé via son ID

// Requete TEST :
// $result = $bdd->exec("DELETE FROM employes WHERE id_employes = 1016");
                                                                // idEmployes : 900
$result = $bdd->exec("DELETE FROM employes WHERE id_employes = '$_POST[idEmployes]'");

$tab['msg'] = "<p class='col-md-5 mx-auto text-center alert alert-success'>L'employé <strong>$_POST[prenomId]</strong> a bien été supprimé !!</p>";

//-------- REQUETE SELECTION + REDEFINITION SELECTEUR 
// Une fois l'employé supprimé (requete DELETE ci dessus), on redéfinit le selecteur contenant les prénoms des employés qui va venir écrasé le selecteur présent sur la page index.php 
$result = $bdd->query("SELECT * FROM employes");

$tab['select'] = '<select class="form-control mb-2" id="prenom">';
while($employes = $result->fetch(PDO::FETCH_ASSOC))
{
    $tab['select'] .= "<option value='$employes[id_employes]'>$employes[id_employes] - $employes[prenom]</option>";
}
$tab['select'] .= '</select>';

echo json_encode($tab); // on encode en JSON le selecteur mis à jour et le message de validation, c'est la requete RETOUR AJAX qui les envoie dans la function(data) du fichier ajax3.js
