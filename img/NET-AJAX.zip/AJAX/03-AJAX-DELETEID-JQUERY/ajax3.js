$(document).ready(function(){

    $('#submit').click(function(event){
        event.preventDefault();
        // alert('click OK!!');

        ajaxDeleteId();
    });

    function ajaxDeleteId()
    {        // 900
        var idEmployes = $('#prenom').val(); // on stock l'id de l'employé dans l'attribut 'value'
        console.log(idEmployes);

        var prenomId = $('#prenom').find(':selected').text(); // on stock le contenu des balises options
        console.log(prenomId);

        // On définit les paramètres a transmettre à la requete AJAX : id_employes + le contenu de la balise <option>
        // parameters est un objet javascript
        var parameters = {
            // idEmployes : 900
            idEmployes : idEmployes, // idEmployes --> $_POST['idEmployes']
            prenomId : prenomId // prenomId --> $_POST['prenomId']
        }

        // var parameters = "idEmployes="+idEmployes+"&prenomId="+prenomId;

        console.log(parameters);

        $.post("ajax3.php", parameters, function(data){
            console.log(data);

            $('#selectEmployes').html(data.select); // on envoie dans la div id '#selectEmployes' le selecteur à jour (moins l'employé supprimé) dans la page index.php  
            $('#resultat').html(data.msg); // on envoie le message de la validation dans la div id '#resultat' dans la page index.php

        }, 'json');
    }

});