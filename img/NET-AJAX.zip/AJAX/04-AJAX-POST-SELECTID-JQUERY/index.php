<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script
    src="https://code.jquery.com/jquery-3.4.1.min.js"
    integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
    crossorigin="anonymous"></script>
    <script src="ajax4.js"></script>
    <title>04 - AJAX - POST - SELECTID - JQUERY</title>
</head>
<body>
    <div class="container">

        <h1 class="display-4 text-center">04 - AJAX - POST - SELECTID - JQUERY</h1><hr>

        <!-- Exo : Réaliser un selecteur en PHP conteant les prénoms des employés (avec l'id_employes dans l'attribut 'value') -->
        <form method="post" action="" class="col-md-4 mx-auto text-center">
            <?php 
            require_once('init.php');
            $result = $bdd->query('SELECT * FROM employes');
            echo '<select class="form-control mb-2" id="prenom">';
            while($employes = $result->fetch(PDO::FETCH_ASSOC))
            {
                echo "<option value='$employes[id_employes]'>$employes[id_employes] - $employes[prenom]</option>";
            }
            echo '</select>';
            ?>
            <input type="submit" id="submit" class="col-md-12 btn btn-dark mb-3" value="Filtrer">
        </form>

        <div id="resultat">
        <!-- Exo : Réaliser le traitement PHP permeattant d'afficher l'ensemble de la table 'employes' sous forme de tableau HTML -->
        <?php 
        $result = $bdd->query('SELECT * FROM employes');
        echo '<table class="table table-bordered text-center"><tr>';
        for($i = 0; $i < $result->columnCount(); $i++)
        {
            $colonne = $result->getColumnMeta($i);
            echo "<th>$colonne[name]</th>";
        }
        echo '</tr>';
        while($employes = $result->fetch(PDO::FETCH_ASSOC))
        {
            echo '<tr>';
            foreach($employes as $value)
            {
                echo "<td>$value</td>";
            }
            echo '</tr>';
        }
        echo '</table>';
        ?>
        </div>

    </div>
</body>
</html>