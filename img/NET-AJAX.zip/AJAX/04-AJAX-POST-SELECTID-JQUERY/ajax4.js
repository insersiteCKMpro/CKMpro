$(document).ready(function(){

    $('#submit').click(function(event){
        event.preventDefault();
        // alert('submit ok!!');

        ajaxSelectId();
    });

    function ajaxSelectId()
    {
        var idEmployes = $('#prenom').val();    
        console.log(idEmployes);

        var parameters = "idEmployes="+idEmployes; // $_POST[idEmployes] = 876
        console.log(parameters);
                                            // data : echo json_encode($tab)
        $.post("ajax4.php", parameters, function(data){
            console.log(data);
            $('#resultat').html(data.tableEmploye); // data.tableEmploye = $tab['tableEmploye'] (ajax4.php)
        }, 'json');
    }

});