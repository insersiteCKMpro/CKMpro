<?php 
require_once('init.php');

$tab = array();

//---------- REQUETE DE SELECTION VIA UN ID
// Exo : réaliser le script permettant se selectionner les données d'1 employé

// Requete TEST : 
// $result = $bdd->query("SELECT * FROM employes WHERE id_employes = 509");
                                                                // $_POST[idEmployes] = 876
$result = $bdd->query("SELECT * FROM employes WHERE id_employes = '$_POST[idEmployes]'");
$employe = $result->fetch(PDO::FETCH_ASSOC);

// Exo : réaliser le script permettant d'afficher les données de l'employé selectionné ci-dessus sous forme de tableau HTML
$tab['tableEmploye'] = '<table class="table table-bordered text-center"><tr>';
for($i = 0; $i < $result->columnCount(); $i++)
{
    $colonne = $result->getColumnMeta($i);
    $tab['tableEmploye'] .= "<th>$colonne[name]</th>";
}
$tab['tableEmploye'] .= '</tr><tr>';
foreach($employe as $value)
{
    $tab['tableEmploye'] .= "<td>$value</td>";
}
$tab['tableEmploye'] .= '</tr></table>';

echo json_encode($tab);