<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script
    src="https://code.jquery.com/jquery-3.4.1.min.js"
    integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
    crossorigin="anonymous"></script>
    <script src="ajax4.js"></script>
    <title>05 - AJAX - POST - SELECT - SERVICE - JQUERY</title>
</head>
<body>
    <div class="container">

        <h1 class="display-4 text-center">05 - AJAX - POST - SELECT - SERVICE - JQUERY</h1><hr>

        <!-- 
        Exo : réaliser un filtre AJAX permettant de filtrer les employés par service 
        - déclarer un selecteur avec les services distinct sur la page index 
        - Afficher l'ensemble des employés sous forme de tableau ARRAY sur la page index.php 
        - Associer l'évènement 'change()' au selecteur (en remplacement de l'évènement click())
        -->

    </div>
</body>
</html>